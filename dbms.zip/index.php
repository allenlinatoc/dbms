
<?php
include 'sys/indexer.php';

$Index = new Index();
$Index->Run();