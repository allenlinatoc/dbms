<?php

$SCHEME_INFOS = DATA::__GetIntent('SCHEME_INFOS');
$DEFAULT_SIZE = 32;


?>