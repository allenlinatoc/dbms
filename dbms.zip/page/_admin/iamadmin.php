<?php

# Current username
$username = USER::Get(USER::USERNAME);
$type = strtolower(USER::Get(USER::TYPE));


?>