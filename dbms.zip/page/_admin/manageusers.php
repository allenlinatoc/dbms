<?php

$sql = new DB();
$sql->Select(['user.id', 'username', 'concat(fname, \' \', lname)'])->
        From('user,profile')->
        Where('user.id=profile.user_id');
$sqlResult = $sql->Query();

$rptUsers = new MYSQLREPORT(array(
    [
        'CAPTION' => 'ID',
        'HIDDEN' => true
    ],
    [
        'CAPTION' => 'Username',
        'class' => 'rpt-header'
    ],
    [
        'CAPTION' => 'Full name',
        'class' => 'rpt-header'
    ],
    [
        'CAPTION' => 'Actions',
        'DEFAULT' => UI::Button('Edit profile', 'button', 'btn btn-primary btn-xs', UI::GetPageUrl('admin-manage-users'), false),
        'class' => 'rpt-header'
    ]
        ));
$rptUsers->setReportProperties(array(
    'width' => '100%',
    'align' => 'center'
))->setReportCellstemplate(array(
    [
        
    ], [
        'class' => 'rpt-cell-lined'
    ], [
        'class' => 'rpt-cell-lined'
    ], [
        'class' => 'rpt-cell-lined'
    ]
));
$rptUsers->loadResultdata($sqlResult);
$rptUsers->defineEmptyMessage('No existing users yet'); 
?>